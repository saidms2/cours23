//
//  AppDelegate.h
//  Cours23PickerView StoryBoard
//
//  Created by Fatiha Kaci (Étudiant) on 18-03-15.
//  Copyright © 2018 Fatiha Kaci (Étudiant). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

