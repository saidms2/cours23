//
//  AnimauxPickerViewDelagate.h
//  Cours23PickerView StoryBoard
//
//  Created by Fatiha Kaci (Étudiant) on 18-03-15.
//  Copyright © 2018 Fatiha Kaci (Étudiant). All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface AnimauxPickerViewDelagate : NSObject <UIPickerViewDelegate,UIPickerViewDataSource >

@property (strong,nonatomic) NSArray* animaux;


@end
