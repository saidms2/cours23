//
//  NavigationController.m
//  Cours23PickerView StoryBoard
//
//  Created by Fatiha Kaci (Étudiant) on 18-03-15.
//  Copyright © 2018 Fatiha Kaci (Étudiant). All rights reserved.
//

#import "NavigationController.h"

@interface NavigationController ()

@end

@implementation NavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(UIInterfaceOrientationMask) supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
- (BOOL) shouldAutorotate {
    return YES;
}
@end
