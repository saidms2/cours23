//
//  NombresPickerViewDelagate.m
//  Cours23PickerView StoryBoard
//
//  Created by Fatiha Kaci (Étudiant) on 18-03-15.
//  Copyright © 2018 Fatiha Kaci (Étudiant). All rights reserved.
//

#import "NombresPickerViewDelagate.h"

@implementation NombresPickerViewDelagate

-(instancetype)init {
    if(self= [super init]) {
        [self setNombres:@[ @"Un",@"Deux",@"Trois",@"quatre" ]];
    }
    return self;
    
}

-(NSInteger) numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

-(NSInteger) pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [[self nombres] count];
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [[self nombres] objectAtIndex:row];
}

-(void) pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    NSLog(@"%@ %@",@"Sélection de l'élément :",[[self nombres] objectAtIndex : row]);
          
}
          

@end
