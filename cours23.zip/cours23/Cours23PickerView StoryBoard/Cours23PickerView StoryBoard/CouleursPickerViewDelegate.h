//
//  CouleursPickerViewDelegate.h
//  Cours23PickerView StoryBoard
//
//  Created by Fatiha Kaci (Étudiant) on 18-03-15.
//  Copyright © 2018 Fatiha Kaci (Étudiant). All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CouleursPickerViewDelegate : NSObject <UIPickerViewDelegate,UIPickerViewDataSource >

@property (strong,nonatomic) NSArray* couleurs;
@property (strong,nonatomic) NSArray* alphas;
@end
