//
//  AppDelegate.h
//  DemoPickerView
//
//  Created by Vincent Leduc on 18-03-09.
//  Copyright © 2018 Vincent Leduc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

